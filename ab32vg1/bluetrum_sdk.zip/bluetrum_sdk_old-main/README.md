# 目录结构

app: 存放 main.c 等应用文件

libs: 存放库

rtos: RTOS 的 wrapper

template: 创建好工程

# TODO

+ SDMMC 驱动
+ AUDIO 驱动
+ 维护 bare-metal 的工程
