/*
 * Copyright (c) 2020-2020, BLUETRUM Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "ab32vg1_hal.h"

#ifdef HAL_DAC_MODULE_ENABLED

WEAK void hal_dac_mspinit(struct dac_handle *hdac)
{}

#endif
